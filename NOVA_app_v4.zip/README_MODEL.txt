Android Studio se khud build kar rahe ho to:
1. https://alphacephei.com/vosk/models se vosk-model-small-en-us-0.15.zip download karo
2. Extract karke folder ka naam "model-en" rakho
3. Usse app/src/main/assets/ ke andar rakho
GitHub Actions se build karoge to ye apne aap hota hai.
