package com.nova.assistant

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * API key is encrypted with AES-256-GCM. The encryption key lives inside the
 * Android Keystore (hardware backed on most phones) and cannot be read out.
 */
object SecureStore {
    private const val ALIAS = "nova_api_key_v1"
    private const val PREF = "nova_secure"
    private const val ENTRY = "api_key"

    private fun secretKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore")
        ks.load(null)
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(
            KeyGenParameterSpec.Builder(
                ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return gen.generateKey()
    }

    fun saveKey(ctx: Context, key: String): Boolean = try {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, secretKey())
        val ct = c.doFinal(key.trim().toByteArray(Charsets.UTF_8))
        val blob = Base64.encodeToString(c.iv + ct, Base64.NO_WRAP)
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(ENTRY, blob).commit()
    } catch (e: Exception) {
        false
    }

    fun getKey(ctx: Context): String = try {
        val blob = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(ENTRY, null)
        if (blob.isNullOrEmpty()) "" else {
            val raw = Base64.decode(blob, Base64.NO_WRAP)
            val iv = raw.copyOfRange(0, 12)
            val ct = raw.copyOfRange(12, raw.size)
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, secretKey(), GCMParameterSpec(128, iv))
            String(c.doFinal(ct), Charsets.UTF_8)
        }
    } catch (e: Exception) {
        ""
    }

    fun hasKey(ctx: Context): Boolean = getKey(ctx).isNotEmpty()

    fun clearKey(ctx: Context) {
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().remove(ENTRY).apply()
    }

    /** Old versions kept the key as plain text. Encrypt it once and delete the plain copy. */
    fun migrateOld(ctx: Context) {
        val old = ctx.getSharedPreferences("nova", Context.MODE_PRIVATE)
        val plain = old.getString("key", "") ?: ""
        if (plain.isNotEmpty() && saveKey(ctx, plain)) {
            old.edit().remove("key").apply()
        }
    }
}
