package com.nova.assistant

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Only job: press the green SEND button in WhatsApp, after the user said "yes".
 *  - accessibility_config.xml limits this service to the WhatsApp packages only.
 *  - It does nothing unless NovaService armed it with a message the user just confirmed.
 *  - It never stores or sends out anything it sees on screen.
 */
class NovaAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance: NovaAccessibilityService? = null
        private val PKGS = setOf("com.whatsapp", "com.whatsapp.w4b")
        private val SEND_WORDS = setOf("send", "भेजें", "भेजे", "enviar", "senden", "envoyer")
        private const val TIMEOUT_MS = 15000L

        fun armSend(message: String, cb: (Boolean) -> Unit) {
            val s = instance
            if (s == null) cb(false) else s.arm(message, cb)
        }

        fun isEnabled(ctx: Context): Boolean {
            if (instance != null) return true
            val s = Settings.Secure.getString(
                ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false
            return s.contains("com.nova.assistant/")
        }
    }

    private class Job(val message: String, val cb: (Boolean) -> Unit, val deadline: Long)

    private val h = Handler(Looper.getMainLooper())
    private var job: Job? = null

    private val tick = object : Runnable {
        override fun run() {
            val j = job ?: return
            if (System.currentTimeMillis() > j.deadline) { done(false); return }
            if (!attempt()) h.postDelayed(this, 500)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        h.removeCallbacksAndMessages(null)
        job?.cb?.invoke(false)
        job = null
        return super.onUnbind(intent)
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (job != null) attempt()
    }

    private fun arm(message: String, cb: (Boolean) -> Unit) {
        h.post {
            job?.cb?.invoke(false)
            job = Job(message, cb, System.currentTimeMillis() + TIMEOUT_MS)
            h.removeCallbacks(tick)
            h.postDelayed(tick, 700)
        }
    }

    private fun done(ok: Boolean) {
        val j = job
        job = null
        h.removeCallbacks(tick)
        j?.cb?.invoke(ok)
    }

    /** True when the job is finished (sent). False = keep waiting. */
    private fun attempt(): Boolean {
        val j = job ?: return true
        val root = rootInActiveWindow ?: return false
        val pkg = root.packageName?.toString() ?: return false
        if (pkg !in PKGS) return false
        // Only press send when the text box holds exactly the message the user confirmed.
        val entry = root.findAccessibilityNodeInfosByViewId("$pkg:id/entry")?.firstOrNull() ?: return false
        val typed = entry.text?.toString() ?: return false
        if (!Logic.sameMessage(typed, j.message)) return false
        val send = findSend(root, pkg) ?: return false
        if (clickNode(send)) { done(true); return true }
        return false
    }

    private fun findSend(root: AccessibilityNodeInfo, pkg: String): AccessibilityNodeInfo? {
        root.findAccessibilityNodeInfosByViewId("$pkg:id/send")?.firstOrNull()?.let { return it }
        return search(root, 0)
    }

    private fun search(n: AccessibilityNodeInfo?, depth: Int): AccessibilityNodeInfo? {
        if (n == null || depth > 12) return null
        val d = n.contentDescription?.toString()?.trim()?.lowercase()
        if (d != null && d in SEND_WORDS && n.isClickable) return n
        for (i in 0 until n.childCount) {
            val r = search(n.getChild(i), depth + 1)
            if (r != null) return r
        }
        return null
    }

    private fun clickNode(n: AccessibilityNodeInfo): Boolean {
        var cur: AccessibilityNodeInfo? = n
        var depth = 0
        while (cur != null && depth < 4) {
            if (cur.isClickable && cur.isEnabled) return cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            cur = cur.parent
            depth++
        }
        return false
    }
}
