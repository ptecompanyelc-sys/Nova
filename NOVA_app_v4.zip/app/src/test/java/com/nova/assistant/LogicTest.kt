package com.nova.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class LogicTest {

    @Test fun wakeWordAcceptsOneEnglishWord() {
        assertEquals("nova", Logic.cleanWake(" Nova "))
        assertEquals("jarvis", Logic.cleanWake("JARVIS"))
    }

    @Test fun wakeWordRejectsBadInput() {
        assertNull(Logic.cleanWake(""))
        assertNull(Logic.cleanWake("ab"))
        assertNull(Logic.cleanWake("hey nova"))
        assertNull(Logic.cleanWake("nova1"))
        assertNull(Logic.cleanWake("abcdefghijklm"))
        assertEquals("nova", Logic.wakeOrDefault("###"))
    }

    @Test fun grammarHasWakeAndUnknown() {
        assertEquals("[\"nova\", \"[unk]\"]", Logic.wakeGrammar("nova"))
    }

    @Test fun modelFallsBackToDefault() {
        assertEquals("gemini-flash-latest", Logic.cleanModel("gemini-flash-latest"))
        assertEquals(Logic.DEFAULT_MODEL, Logic.cleanModel("gemini-2.5-flash"))
        assertEquals(Logic.DEFAULT_MODEL, Logic.cleanModel("gpt-4"))
        assertEquals(Logic.DEFAULT_MODEL, Logic.cleanModel(null))
    }

    @Test fun voiceValuesAreClamped() {
        assertEquals(1.6f, Logic.clampRate(9f), 0.0001f)
        assertEquals(0.6f, Logic.clampRate(0f), 0.0001f)
        assertEquals(1.4f, Logic.clampPitch(5f), 0.0001f)
        assertEquals(0.7f, Logic.clampPitch(0.1f), 0.0001f)
    }

    @Test fun readsVoskJson() {
        assertEquals("nova", Logic.extractText("{\n  \"text\" : \"nova\"\n}"))
        assertEquals("nova", Logic.extractText("{\"partial\" : \"nova\"}"))
        assertEquals("", Logic.extractText("{\"partial\" : \"\"}"))
        assertEquals("", Logic.extractText("garbage"))
    }

    @Test fun wakeWordMustBeWholeWord() {
        assertTrue(Logic.heardWake("{\"partial\" : \"nova\"}", "nova"))
        assertTrue(Logic.heardWake("{\"text\" : \"[unk] nova\"}", "nova"))
        assertFalse(Logic.heardWake("{\"partial\" : \"novas\"}", "nova"))
        assertFalse(Logic.heardWake("{\"partial\" : \"\"}", "nova"))
        // the JSON key "text" must never count as the wake word
        assertFalse(Logic.heardWake("{\"partial\" : \"\"}", "text"))
    }

    @Test fun yesNoAnswers() {
        assertEquals(true, Logic.parseAnswer("yes"))
        assertEquals(true, Logic.parseAnswer("okay"))
        assertEquals(false, Logic.parseAnswer("no"))
        assertEquals(false, Logic.parseAnswer("cancel"))
        assertEquals(false, Logic.parseAnswer("yes stop"))
        assertNull(Logic.parseAnswer(""))
        assertNull(Logic.parseAnswer("[unk]"))
        assertNull(Logic.parseAnswer("torch on"))
    }

    @Test fun messageComparisonIgnoresSpacesAndCase() {
        assertTrue(Logic.sameMessage("  Kal  milte hain ", "kal milte hain"))
        assertFalse(Logic.sameMessage("kal milte hain", "aaj milte hain"))
    }

    @Test fun whatsappNumbers() {
        assertEquals("919876543210", Logic.waNumber("98765 43210"))
        assertEquals("919876543210", Logic.waNumber("09876543210"))
        assertEquals("919876543210", Logic.waNumber("+91 98765-43210"))
        assertEquals("14155550123", Logic.waNumber("+1 415 555 0123"))
    }

    @Test fun longTextIsShortened() {
        assertEquals("hello", Logic.shorten("hello", 10))
        assertTrue(Logic.shorten("a".repeat(500), 50).length <= 53)
    }

    @Test fun picksBestContact() {
        val names = listOf("Rahul Sharma", "Rahul", "Rahulika", "Mr Rahul Verma")
        assertEquals(1, Logic.pickContact("rahul", names))
        assertEquals(0, Logic.pickContact("sharma", names))
        assertEquals(-1, Logic.pickContact("rahul", emptyList()))
        // no whole-word match: shortest name wins
        assertEquals(0, Logic.pickContact("rah", listOf("Rahul", "Rahulika")))
    }
}
