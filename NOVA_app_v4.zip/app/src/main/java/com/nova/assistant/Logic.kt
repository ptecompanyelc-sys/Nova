package com.nova.assistant

/** Pure logic (no Android classes) so GitHub can unit-test it on every change. */
object Logic {
    const val DEFAULT_WAKE = "nova"
    const val DEFAULT_MODEL = "gemini-3.5-flash"
    val MODELS = listOf("gemini-3.5-flash", "gemini-flash-latest")

    /** Wake word: one English word, 3-12 letters. Returns null if not valid. */
    fun cleanWake(raw: String?): String? {
        val w = (raw ?: "").trim().lowercase()
        if (w.length < 3 || w.length > 12) return null
        if (!w.all { it in 'a'..'z' }) return null
        return w
    }

    fun wakeOrDefault(raw: String?): String = cleanWake(raw) ?: DEFAULT_WAKE

    fun wakeGrammar(w: String): String = "[\"$w\", \"[unk]\"]"

    fun cleanModel(raw: String?): String = if (raw != null && raw in MODELS) raw else DEFAULT_MODEL

    fun clampRate(v: Float): Float = v.coerceIn(0.6f, 1.6f)
    fun clampPitch(v: Float): Float = v.coerceIn(0.7f, 1.4f)

    private val TEXT_RE = Regex("\"(?:text|partial)\"\\s*:\\s*\"([^\"]*)\"")

    /** Reads the spoken text out of a Vosk JSON result. */
    fun extractText(json: String): String = TEXT_RE.find(json)?.groupValues?.get(1)?.trim() ?: ""

    fun heardWake(json: String, wake: String): Boolean =
        extractText(json).split(" ").any { it == wake }

    /**
     * Quick offline reading of a yes/no answer.
     * false = clearly "no", true = clearly "yes", null = not sure.
     */
    fun parseAnswer(text: String): Boolean? {
        val w = text.trim().lowercase().split(" ").filter { it.isNotBlank() && it != "[unk]" }
        if (w.isEmpty()) return null
        val neg = setOf("no", "cancel", "stop")
        val pos = setOf("yes", "yeah", "okay", "ok")
        if (w.any { it in neg }) return false
        if (w.all { it in pos }) return true
        return null
    }

    fun normalizeMsg(s: String): String = s.trim().lowercase().replace(Regex("\\s+"), " ")

    fun sameMessage(a: String, b: String): Boolean = normalizeMsg(a) == normalizeMsg(b)

    /** Digits for a wa.me link. 10 digit numbers are treated as Indian (+91). */
    fun waNumber(raw: String): String {
        val d = raw.filter { it.isDigit() }
        return when {
            d.length == 10 -> "91$d"
            d.length == 11 && d.startsWith("0") -> "91" + d.substring(1)
            else -> d
        }
    }

    fun shorten(s: String, max: Int = 160): String =
        if (s.length <= max) s else s.substring(0, max).trimEnd() + "..."

    /** Picks the best contact for a spoken name. Returns index or -1. */
    fun pickContact(query: String, names: List<String>): Int {
        if (names.isEmpty()) return -1
        val q = query.trim().lowercase()
        val exact = names.indexOfFirst { it.trim().lowercase() == q }
        if (exact >= 0) return exact
        val word = names.indices.filter { i -> names[i].lowercase().split(" ", "-").contains(q) }
        if (word.isNotEmpty()) return word.minByOrNull { names[it].length } ?: -1
        return names.indices.minByOrNull { names[it].length } ?: -1
    }
}
