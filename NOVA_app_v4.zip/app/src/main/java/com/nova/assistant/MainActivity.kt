package com.nova.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var cfg: Cfg
    private var testTts: TextToSpeech? = null

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        cfg = Cfg(this)
        SecureStore.migrateOld(this)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.setBackgroundColor(0)
        web.addJavascriptInterface(Bridge(), "Android")
        web.loadUrl("file:///android_asset/ui.html")
        setContentView(web)
        NovaService.listener = { role, text ->
            runOnUiThread {
                web.evaluateJavascript(
                    "onNova(" + JSONObject.quote(role) + "," + JSONObject.quote(text) + ")", null
                )
            }
        }
        handleIntent(intent)
    }

    override fun onNewIntent(i: Intent?) {
        super.onNewIntent(i)
        setIntent(i)
        handleIntent(i)
    }

    override fun onDestroy() {
        NovaService.listener = null
        testTts?.shutdown()
        super.onDestroy()
    }

    // Tapped "NOVA chalu karo" notification after a phone restart
    private fun handleIntent(i: Intent?) {
        if (i?.getBooleanExtra("autostart", false) == true && !NovaService.running) {
            i.removeExtra("autostart")
            if (startFlow() == "started") moveTaskToBack(true)
        }
    }

    private fun granted(p: String) =
        checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    /** Asks for missing permissions, then starts NOVA. Returns a short status word for the UI. */
    private fun startFlow(): String {
        val svc = Intent(this, NovaService::class.java)
        val prefs = getSharedPreferences("nova", MODE_PRIVATE)
        val all = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.CALL_PHONE
        )
        if (Build.VERSION.SDK_INT >= 33) all.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = all.filter { !granted(it) }
        if (missing.isNotEmpty() && !prefs.getBoolean("askedPerms", false)) {
            prefs.edit().putBoolean("askedPerms", true).apply()
            runOnUiThread { requestPermissions(missing.toTypedArray(), 1) }
            return "perm"
        }
        if (!granted(Manifest.permission.RECORD_AUDIO)) return "nomic"
        if (!Settings.canDrawOverlays(this) && !prefs.getBoolean("askedOverlay", false)) {
            prefs.edit().putBoolean("askedOverlay", true).apply()
            runOnUiThread {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                )
            }
            return "overlay"
        }
        cfg.active = true
        runOnUiThread { startForegroundService(svc) }
        return "started"
    }

    inner class Bridge {
        @JavascriptInterface
        fun running() = NovaService.running

        @JavascriptInterface
        fun hasKey() = SecureStore.hasKey(this@MainActivity)

        /** The key is only ever written here, never sent back to the page. */
        @JavascriptInterface
        fun saveKey(k: String): String =
            if (k.isNotBlank() && SecureStore.saveKey(this@MainActivity, k)) "ok" else "fail"

        @JavascriptInterface
        fun clearKey() { SecureStore.clearKey(this@MainActivity) }

        @JavascriptInterface
        fun stopSpeak() { NovaService.instance?.stopSpeaking() }

        @JavascriptInterface
        fun toggle(): String {
            if (NovaService.running) {
                cfg.active = false
                runOnUiThread { stopService(Intent(this@MainActivity, NovaService::class.java)) }
                return "stopped"
            }
            return startFlow()
        }

        @JavascriptInterface
        fun getSettings(): String = JSONObject()
            .put("wake", cfg.wake)
            .put("lang", cfg.lang)
            .put("rate", cfg.rate.toDouble())
            .put("pitch", cfg.pitch.toDouble())
            .put("model", cfg.model)
            .put("models", JSONArray(Logic.MODELS))
            .put("autostart", cfg.autostart)
            .put("hasKey", SecureStore.hasKey(this@MainActivity))
            .put("acc", NovaAccessibilityService.isEnabled(this@MainActivity))
            .put("running", NovaService.running)
            .toString()

        @JavascriptInterface
        fun saveSettings(json: String): String {
            return try {
                val o = JSONObject(json)
                val w = Logic.cleanWake(o.optString("wake"))
                if (w == null) return "bad_wake"
                cfg.wake = w
                cfg.lang = if (o.optString("lang") == "en") "en" else "hi"
                cfg.rate = Logic.clampRate(o.optDouble("rate", 1.0).toFloat())
                cfg.pitch = Logic.clampPitch(o.optDouble("pitch", 1.0).toFloat())
                cfg.model = Logic.cleanModel(o.optString("model"))
                cfg.autostart = o.optBoolean("autostart", true)
                NovaService.instance?.reloadVoice()
                "ok"
            } catch (e: Exception) {
                "error"
            }
        }

        @JavascriptInterface
        fun testVoice() {
            runOnUiThread {
                val text = if (cfg.lang == "en") "Hello, I am Nova" else "नमस्ते, मैं नोवा हूँ"
                val svc = NovaService.instance
                if (svc != null) {
                    svc.speakTest(text)
                } else {
                    testTts?.shutdown()
                    testTts = TextToSpeech(this@MainActivity) { st ->
                        if (st == TextToSpeech.SUCCESS) {
                            cfg.applyVoice(testTts)
                            testTts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "test")
                        }
                    }
                }
            }
        }

        @JavascriptInterface
        fun openAccessibility() {
            runOnUiThread { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }

        @JavascriptInterface
        fun openAppInfo() {
            runOnUiThread {
                startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
                )
            }
        }
    }
}
