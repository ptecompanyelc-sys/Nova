package com.nova.assistant

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.hardware.camera2.CameraManager
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.ToneGenerator
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class NovaService : Service() {

    companion object {
        var running = false
        var listener: ((String, String) -> Unit)? = null
        var instance: NovaService? = null

        const val RATE = 16000
        const val CONFIRM_ID = "nova-confirm"
        // yes / no / okay / cancel / stop added so a confirmation answer can be read offline
        const val CMD_GRAMMAR = "[\"torch\",\"flashlight\",\"on\",\"off\",\"volume\",\"up\",\"down\",\"max\",\"mute\",\"battery\",\"time\",\"open\",\"youtube\",\"google\",\"whatsapp\",\"camera\",\"settings\",\"wifi\",\"bluetooth\",\"yes\",\"yeah\",\"okay\",\"ok\",\"no\",\"cancel\",\"stop\",\"[unk]\"]"
    }

    // An action that waits for the user's spoken "yes" (call, WhatsApp send)
    private class Pending(val prompt: String, val run: () -> String)

    private val h = Handler(Looper.getMainLooper())
    private lateinit var cfg: Cfg
    private var tts: TextToSpeech? = null
    @Volatile private var busy = false
    @Volatile private var pending: Pending? = null
    @Volatile private var answerWindow = false
    private val history = ArrayList<JSONObject>()
    private var apiKey = ""

    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, s: Int) = START_STICKY

    private fun tr(hi: String, en: String): String = if (cfg.lang == "en") en else hi

    override fun onCreate() {
        super.onCreate()
        cfg = Cfg(this)
        instance = this
        SecureStore.migrateOld(this)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("nova", "NOVA", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, "nova")
            .setContentTitle(tr("NOVA active hai", "NOVA is active"))
            .setContentText(tr("\"${cfg.wake}\" bolo, main sun raha hoon", "Say \"${cfg.wake}\", I am listening"))
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            } else {
                startForeground(1, n)
            }
        } catch (e: Exception) {
            // Android does not allow the mic service to start from the background.
            BootReceiver.showTapToStart(this)
            cfg.active = false
            stopSelf()
            return
        }
        tts = TextToSpeech(this) { st ->
            if (st == TextToSpeech.SUCCESS) {
                cfg.applyVoice(tts)
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) {}
                    override fun onDone(id: String?) { if (id == CONFIRM_ID) answerWindow = true }
                    @Deprecated("Deprecated in Java")
                    override fun onError(id: String?) { if (id == CONFIRM_ID) answerWindow = true }
                })
            }
        }
        running = true
        Thread { audioLoop() }.start()
    }

    override fun onDestroy() {
        running = false
        instance = null
        h.removeCallbacksAndMessages(null)
        tts?.shutdown()
        super.onDestroy()
    }

    fun stopSpeaking() { tts?.stop() }
    fun reloadVoice() { cfg.applyVoice(tts) }
    fun speakTest(text: String) {
        cfg.applyVoice(tts)
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "test")
    }

    private fun mode(m: String) { listener?.invoke("mode", m) }
    private fun sys(t: String) { listener?.invoke("sys", t) }

    private fun say(text: String, confirm: Boolean = false) {
        if (text.isEmpty()) return
        listener?.invoke("ai", text)
        val t = tts
        if (t == null) {
            if (confirm) answerWindow = true
            return
        }
        cfg.applyVoice(t)
        t.speak(text, TextToSpeech.QUEUE_FLUSH, null, if (confirm) CONFIRM_ID else "nova")
    }

    // ---------- Offline wake word model (Vosk) ----------
    private fun copyAssets(path: String, dest: File) {
        val list = assets.list(path)
        if (list == null || list.isEmpty()) {
            dest.parentFile?.mkdirs()
            assets.open(path).use { i -> dest.outputStream().use { o -> i.copyTo(o) } }
        } else {
            dest.mkdirs()
            for (n in list) copyAssets("$path/$n", File(dest, n))
        }
    }

    private fun loadModel(): Model {
        val dir = File(filesDir, "model-en")
        val ok = File(dir, ".done")
        if (!ok.exists()) {
            sys(tr("Pehli baar model tayyar ho raha hai, thoda ruko...", "Preparing the model for the first time..."))
            dir.deleteRecursively()
            copyAssets("model-en", dir)
            ok.writeText("1")
        }
        return Model(dir.absolutePath)
    }

    /** The chosen wake word must exist in the Vosk vocabulary, else we use the default. */
    private fun resolveWake(): String {
        val w = cfg.wake
        if (w == Logic.DEFAULT_WAKE) return w
        return try {
            val f = File(filesDir, "model-en/graph/words.txt")
            if (!f.exists()) w
            else {
                val found = f.useLines { lines ->
                    lines.any { it.substringBefore(' ').substringBefore('\t') == w }
                }
                if (found) w else {
                    listener?.invoke("ai", tr(
                        "\"$w\" shabd model mein nahi mila, abhi \"nova\" use kar raha hoon. Settings mein doosra shabd try karo.",
                        "\"$w\" is not in the model vocabulary, using \"nova\" for now. Try another word in Settings."
                    ))
                    Logic.DEFAULT_WAKE
                }
            }
        } catch (e: Exception) { w }
    }

    // ---------- Mic loop: wake word -> record command -> process ----------
    private fun audioLoop() {
        val model: Model = try {
            loadModel()
        } catch (e: Exception) {
            listener?.invoke("ai", tr(
                "Wake word model nahi mila. GitHub build mein model wala step check karo.",
                "Wake word model not found. Check the model step in the GitHub build."
            ))
            cfg.active = false
            stopSelf()
            return
        }
        val wakeWord = resolveWake()
        var wake: Recognizer? = null
        var cmd: Recognizer? = null
        var rec: AudioRecord? = null
        var tone: ToneGenerator? = null
        try {
            val wk = Recognizer(model, RATE.toFloat(), Logic.wakeGrammar(wakeWord))
            wake = wk
            val cm = Recognizer(model, RATE.toFloat(), CMD_GRAMMAR)
            cmd = cm
            val minBuf = AudioRecord.getMinBufferSize(
                RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            val rc = AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION, RATE,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                maxOf(minBuf, 16384)
            )
            rec = rc
            if (rc.state != AudioRecord.STATE_INITIALIZED) {
                listener?.invoke("ai", tr("Mic start nahi hua. Mic permission check karo.", "Mic did not start. Check the mic permission."))
                cfg.active = false
                stopSelf()
                return
            }
            val tn = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 70)
            tone = tn
            rc.startRecording()
            mode("on")
            sys(tr("Listening - bolo \"$wakeWord\"", "Listening - say \"$wakeWord\""))

            val buf = ShortArray(1600) // 100 ms
            var capturing = false
            var answerCapture = false
            var pcm = ByteArrayOutputStream()
            var heard = false
            var silentMs = 0
            var totalMs = 0
            var skip = 0
            var noise = 300.0

            fun startCapture(answer: Boolean) {
                wk.reset()
                cm.reset()
                tn.startTone(ToneGenerator.TONE_PROP_BEEP, 120)
                capturing = true
                answerCapture = answer
                pcm = ByteArrayOutputStream()
                heard = false
                silentMs = 0
                totalMs = 0
                skip = 3
                mode("listen")
                sys(
                    if (answer) tr("Haan ya nahi bolo...", "Say yes or no...")
                    else tr("Bolo, main sun raha hoon...", "Speak, I am listening...")
                )
            }

            while (running) {
                val n = rc.read(buf, 0, buf.size)
                if (n <= 0) continue
                if (busy || tts?.isSpeaking == true) { capturing = false; continue }

                var sum = 0.0
                for (i in 0 until n) sum += buf[i].toDouble() * buf[i]
                val rms = Math.sqrt(sum / n)

                if (!capturing) {
                    if (answerWindow) {
                        answerWindow = false
                        if (pending != null) { startCapture(true); continue }
                    }
                    noise = noise * 0.97 + minOf(rms, 1500.0) * 0.03
                    val done = wk.acceptWaveForm(buf, n)
                    val txt = if (done) wk.getResult() else wk.getPartialResult()
                    if (Logic.heardWake(txt, wakeWord)) {
                        pending = null // a new command cancels any waiting confirmation
                        startCapture(false)
                    }
                } else {
                    if (skip > 0) { skip--; continue }
                    totalMs += 100
                    val speaking = rms > maxOf(700.0, noise * 3)
                    if (speaking) { heard = true; silentMs = 0 } else if (heard) silentMs += 100
                    for (i in 0 until n) {
                        pcm.write(buf[i].toInt() and 0xff)
                        pcm.write((buf[i].toInt() shr 8) and 0xff)
                    }
                    cm.acceptWaveForm(buf, n)
                    val end = (heard && silentMs >= 1000) || totalMs >= 12000 || (!heard && totalMs >= 5000)
                    if (end) {
                        capturing = false
                        val isAnswer = answerCapture
                        answerCapture = false
                        val bytes = pcm.toByteArray()
                        val localText = try {
                            JSONObject(cm.getFinalResult()).optString("text")
                        } catch (e: Exception) { "" }
                        cm.reset()
                        wk.reset()
                        if (!heard) {
                            mode("on")
                            if (isAnswer) {
                                pending = null
                                say(tr("Jawab nahi mila, isliye cancel kar diya", "No answer heard, so I cancelled it"))
                            } else {
                                sys(tr("Kuch suna nahi, dobara \"$wakeWord\" bolo", "Heard nothing, say \"$wakeWord\" again"))
                            }
                            continue
                        }
                        busy = true
                        mode("think")
                        sys(tr("Soch raha hoon...", "Thinking..."))
                        val dur = totalMs
                        if (isAnswer) Thread { processAnswer(bytes, localText, dur) }.start()
                        else Thread { process(bytes, localText, dur) }.start()
                    }
                }
            }
        } catch (e: Exception) {
            listener?.invoke("ai", "Mic loop error: " + e.message)
        } finally {
            try { rec?.stop() } catch (e: Exception) {}
            try { rec?.release() } catch (e: Exception) {}
            try { tone?.release() } catch (e: Exception) {}
            try { wake?.close() } catch (e: Exception) {}
            try { cmd?.close() } catch (e: Exception) {}
            try { model.close() } catch (e: Exception) {}
        }
    }

    private fun finishTurn(reply: String) {
        h.post { busy = false; say(reply, pending != null) }
    }

    private fun process(pcm: ByteArray, localText: String, durMs: Int) {
        val reply: String = try {
            val l = localCommand(localText, durMs)
            if (l != null) {
                listener?.invoke("me", "🎤 " + localText)
                l
            } else {
                listener?.invoke("me", "🎤 " + tr("(आवाज़)", "(voice)"))
                askAI(pcm)
            }
        } catch (e: Exception) {
            tr("नेटवर्क या एपीआई में दिक्कत आई", "Network or API problem")
        }
        finishTurn(reply)
    }

    // The user answered "Rahul ko call karun?" - anything unclear means NO.
    private fun processAnswer(pcm: ByteArray, localText: String, durMs: Int) {
        val p = pending
        pending = null
        if (p == null) { process(pcm, localText, durMs); return }
        listener?.invoke("me", "🎤 " + tr("(जवाब)", "(answer)"))
        val local = Logic.parseAnswer(localText)
        val yes: Boolean? = if (local == false) false else {
            try { askYesNo(pcm) } catch (e: Exception) { if (local == true) true else null }
        }
        val reply: String = when (yes) {
            true -> try { p.run() } catch (e: Exception) { tr("काम नहीं हो पाया", "That did not work") }
            false -> tr("ठीक है, रद्द कर दिया", "Okay, cancelled")
            null -> tr("समझ नहीं आया, इसलिए रद्द कर दिया", "I did not understand, so I cancelled it")
        }
        finishTurn(reply)
    }

    private fun askFirst(prompt: String, run: () -> String): String {
        if (pending != null) return "another confirmation is already waiting"
        pending = Pending(prompt, run)
        return "waiting for the user's voice confirmation"
    }

    // ---------- Offline commands (no AI, no internet, instant) ----------
    private fun localCommand(text: String, durMs: Int): String? {
        val tk = text.trim().split(" ").filter { it.isNotBlank() }
        val w = tk.filter { it != "[unk]" }.toSet()
        val unk = tk.count { it == "[unk]" }
        if (w.isEmpty() || tk.size > 4 || unk > 1 || durMs > 5000) return null
        return when {
            ("torch" in w || "flashlight" in w) && ("on" in w || "off" in w) -> {
                val on = "off" !in w
                runTool("torch", JSONObject().put("on", on))
                if (on) tr("टॉर्च ऑन", "Torch on") else tr("टॉर्च ऑफ", "Torch off")
            }
            "volume" in w && ("up" in w || "down" in w || "max" in w || "mute" in w) -> {
                val a = listOf("max", "mute", "down", "up").first { it in w }
                runTool("volume", JSONObject().put("action", a))
                tr("वॉल्यूम बदल दिया", "Volume changed")
            }
            "battery" in w -> {
                val bat = getSystemService(BatteryManager::class.java)
                    .getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
                tr("बैटरी $bat प्रतिशत है", "Battery is at $bat percent")
            }
            "time" in w ->
                tr("अभी ", "It is ") + SimpleDateFormat("hh:mm a", Locale.ENGLISH).format(Date()) + tr(" हुए हैं", "")
            "open" in w -> openLocal(w)
            else -> null
        }
    }

    private fun openLocal(w: Set<String>): String? {
        fun app(label: String, url: String) {
            if (runTool("open_app", JSONObject().put("name", label)) != "done")
                runTool("open_url", JSONObject().put("url", url))
        }
        return when {
            "youtube" in w -> { app("YouTube", "https://youtube.com"); tr("यूट्यूब खोल दिया", "YouTube opened") }
            "google" in w -> { app("Google", "https://google.com"); tr("गूगल खोल दिया", "Google opened") }
            "whatsapp" in w -> { app("WhatsApp", "https://wa.me/"); tr("व्हाट्सऐप खोल दिया", "WhatsApp opened") }
            "camera" in w -> { runTool("camera", JSONObject()); tr("कैमरा खोल दिया", "Camera opened") }
            "wifi" in w -> { runTool("settings", JSONObject().put("page", "wifi")); tr("वाई-फाई सेटिंग खोल दी", "Wi-Fi settings opened") }
            "bluetooth" in w -> { runTool("settings", JSONObject().put("page", "bluetooth")); tr("ब्लूटूथ सेटिंग खोल दी", "Bluetooth settings opened") }
            "settings" in w -> { runTool("settings", JSONObject().put("page", "main")); tr("सेटिंग खोल दी", "Settings opened") }
            else -> null
        }
    }

    // ---------- Gemini API (free tier), audio goes directly to Gemini ----------
    private fun tool(name: String, desc: String, vararg params: Pair<String, String>): JSONObject {
        val d = JSONObject().put("name", name).put("description", desc)
        if (params.isNotEmpty()) {
            val props = JSONObject()
            val req = JSONArray()
            params.forEach { (n, t) -> props.put(n, JSONObject().put("type", t.uppercase())); req.put(n) }
            d.put("parameters", JSONObject().put("type", "OBJECT").put("properties", props).put("required", req))
        }
        return d
    }

    private fun system(): String {
        val now = SimpleDateFormat("EEEE, d MMMM yyyy, hh:mm a", Locale.ENGLISH).format(Date())
        val bat = getSystemService(BatteryManager::class.java)
            .getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        return """You are NOVA, a voice assistant running on the user's Android phone. The user's message is a short audio recording of a spoken command in Hindi, Hinglish or English: understand it directly. If the audio is empty or unclear, ask the user briefly to repeat. Your replies are read aloud by text-to-speech, so: no markdown, no lists, no emojis, no URLs, short natural sentences. Reply in the language the user spoke: Hindi in Devanagari script for Hindi or Hinglish, English for English. Use the provided tools to perform phone actions whenever the user asks for one, and never claim an action was done unless the tool succeeded. The call and whatsapp tools ask the user for a spoken yes or no by themselves, so call the tool directly without asking first. When using call, sms or whatsapp, pass the contact name in Latin letters the way it is usually saved in a phone, for example Rahul, not in Devanagari. For whatsapp, pass only the final message text the user wants to send. When asked for analysis, opinions, comparisons or explanations, give a clear reasoned answer: conclusion first, then the two to four most important reasons, then key risks or uncertainty. Use the search_web tool for anything current such as news, prices, scores or markets. Keep answers under about 8 sentences unless the user asks for detail. Never call or message anyone the user did not ask for. Current time: $now. Phone battery: $bat percent."""
    }

    private fun declarations(): JSONArray {
        val t = JSONArray()
        t.put(tool("open_app", "Open an installed app by its English name, e.g. WhatsApp, Instagram, Camera, Calculator", "name" to "string"))
        t.put(tool("open_url", "Open a web page in the browser", "url" to "string"))
        t.put(tool("call", "Phone call a saved contact name or a phone number. The user is asked to confirm by voice first", "who" to "string"))
        t.put(tool("sms", "Open the SMS app with a prefilled message to a contact name or number", "to" to "string", "message" to "string"))
        t.put(tool("whatsapp", "Send a WhatsApp message to a contact name or number. The user is asked to confirm by voice first, then the message is sent", "to" to "string", "message" to "string"))
        t.put(tool("alarm", "Set an alarm (24-hour clock)", "hour" to "integer", "minute" to "integer", "label" to "string"))
        t.put(tool("timer", "Start a countdown timer", "seconds" to "integer", "label" to "string"))
        t.put(tool("torch", "Turn the flashlight on or off", "on" to "boolean"))
        t.put(tool("volume", "Change media volume: action is one of up, down, mute, max", "action" to "string"))
        t.put(tool("navigate", "Start navigation or show a place in Google Maps", "place" to "string"))
        t.put(tool("play_music", "Search and play a song or video on YouTube", "query" to "string"))
        t.put(tool("camera", "Open the camera"))
        t.put(tool("settings", "Open a phone settings page: wifi, bluetooth, display, sound, location, battery, airplane, apps, dnd, or main", "page" to "string"))
        t.put(tool("calendar_event", "Create a calendar event. start is local time like 2026-10-09T18:00", "title" to "string", "start" to "string"))
        t.put(tool("search_web", "Search the internet for current information (news, prices, scores, markets) and get a text summary", "query" to "string"))
        return t
    }

    private fun body(contents: JSONArray): String =
        JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system()))))
            .put("contents", contents)
            .put("tools", JSONArray().put(JSONObject().put("functionDeclarations", declarations())))
            .put("generationConfig", JSONObject().put("thinkingConfig", JSONObject().put("thinkingBudget", 1024)))
            .toString()

    private fun post(model: String, key: String, json: String): Pair<Int, String> {
        val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            .openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 15000
        c.readTimeout = 60000
        c.doOutput = true
        c.setRequestProperty("content-type", "application/json")
        c.setRequestProperty("x-goog-api-key", key)
        c.outputStream.use { it.write(json.toByteArray()) }
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
        return Pair(code, text)
    }

    private fun msg(role: String, text: String) =
        JSONObject().put("role", role).put("parts", JSONArray().put(JSONObject().put("text", text)))

    private fun wavBytes(pcm: ByteArray): ByteArray {
        val out = ByteArrayOutputStream()
        fun i32(v: Int) {
            out.write(v and 0xff); out.write((v shr 8) and 0xff)
            out.write((v shr 16) and 0xff); out.write((v shr 24) and 0xff)
        }
        fun i16(v: Int) { out.write(v and 0xff); out.write((v shr 8) and 0xff) }
        out.write("RIFF".toByteArray()); i32(36 + pcm.size); out.write("WAVE".toByteArray())
        out.write("fmt ".toByteArray()); i32(16); i16(1); i16(1); i32(RATE); i32(RATE * 2); i16(2); i16(16)
        out.write("data".toByteArray()); i32(pcm.size); out.write(pcm)
        return out.toByteArray()
    }

    // Google Search grounding runs as a separate call (free tier can't mix it with function tools)
    private fun searchWeb(q: String): String {
        val b = JSONObject()
            .put("contents", JSONArray().put(msg("user", q + "\nGive a concise factual summary with key numbers and dates.")))
            .put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
            .toString()
        val (code, resp) = post(cfg.model, apiKey, b)
        if (code != 200) return "search failed ($code)"
        val parts = JSONObject(resp).optJSONArray("candidates")?.optJSONObject(0)
            ?.optJSONObject("content")?.optJSONArray("parts") ?: return "no result"
        val sb = StringBuilder()
        for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text")).append(' ')
        return sb.toString().trim()
    }

    /** Asks Gemini to hear a short reply and say YES / NO. null = unclear. Throws if the call fails. */
    private fun askYesNo(pcm: ByteArray): Boolean? {
        val key = SecureStore.getKey(this)
        if (key.isEmpty()) throw IllegalStateException("no key")
        val audio = Base64.encodeToString(wavBytes(pcm), Base64.NO_WRAP)
        val mdl = cfg.model
        val instruction = "The audio is a short spoken reply (Hindi, Hinglish or English) to a yes/no confirmation question. " +
            "Answer with exactly one word. YES if the speaker agrees (haan, ha, ji, kar do, theek hai, yes, okay). " +
            "NO if the speaker refuses or says stop or cancel (nahi, mat karo, ruko, no). " +
            "UNCLEAR if it is silent, noisy, or anything else. When in doubt, answer UNCLEAR."
        val userParts = JSONArray()
            .put(JSONObject().put("inlineData", JSONObject().put("mimeType", "audio/wav").put("data", audio)))
            .put(JSONObject().put("text", "Classify the reply."))
        val b = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", instruction))))
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", userParts)))
            .put("generationConfig", JSONObject()
                .put("maxOutputTokens", 200)
                .put("thinkingConfig", JSONObject().put("thinkingBudget", 0)))
            .toString()
        val (code, resp) = post(mdl, key, b)
        if (code != 200) throw IllegalStateException("api $code")
        val parts = JSONObject(resp).optJSONArray("candidates")?.optJSONObject(0)
            ?.optJSONObject("content")?.optJSONArray("parts") ?: return null
        val sb = StringBuilder()
        for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
        val t = sb.toString().trim().uppercase()
        return when {
            t.startsWith("YES") -> true
            t.startsWith("NO") -> false
            else -> null
        }
    }

    private fun askAI(pcm: ByteArray): String {
        apiKey = SecureStore.getKey(this)
        if (apiKey.isEmpty()) return tr("पहले ऐप में एपीआई की डालिए", "Please add the API key in Settings first")
        val audio = Base64.encodeToString(wavBytes(pcm), Base64.NO_WRAP)
        val userMsg = JSONObject().put("role", "user").put(
            "parts",
            JSONArray()
                .put(JSONObject().put("inlineData", JSONObject().put("mimeType", "audio/wav").put("data", audio)))
                .put(JSONObject().put("text", "(This audio is the user's spoken command, said after the wake word. Understand it and act on it.)"))
        )
        val contents = JSONArray()
        history.forEach { contents.put(it) }
        contents.put(userMsg)
        var steps = 0
        while (steps++ < 8) {
            val (code, resp) = post(cfg.model, apiKey, body(contents))
            if (code != 200) return when (code) {
                429 -> tr("लिमिट पूरी हो गई, थोड़ी देर बाद कोशिश करो", "Limit reached, try again in a while")
                400, 401, 403 -> tr("एपीआई की गलत है", "The API key looks wrong")
                else -> tr("एपीआई एरर $code", "API error $code")
            }
            val content = JSONObject(resp).optJSONArray("candidates")?.optJSONObject(0)
                ?.optJSONObject("content") ?: return tr("जवाब नहीं मिला", "No answer received")
            val parts = content.optJSONArray("parts") ?: return tr("जवाब नहीं मिला", "No answer received")
            val calls = ArrayList<JSONObject>()
            val sb = StringBuilder()
            for (i in 0 until parts.length()) {
                val p = parts.getJSONObject(i)
                if (p.has("functionCall")) calls.add(p.getJSONObject("functionCall"))
                else if (p.has("text") && !p.optBoolean("thought", false)) sb.append(p.getString("text")).append(' ')
            }
            if (calls.isNotEmpty()) {
                contents.put(content)
                val res = JSONArray()
                for (fc in calls) {
                    val name = fc.getString("name")
                    val out = try { runTool(name, fc.optJSONObject("args") ?: JSONObject()) }
                              catch (e: Exception) { "error: " + e.message }
                    res.put(JSONObject().put("functionResponse",
                        JSONObject().put("name", name).put("response", JSONObject().put("result", out))))
                }
                // A call / WhatsApp send is waiting for "yes": ask the user right now.
                val wait = pending
                if (wait != null) {
                    history.add(userMsg)
                    history.add(msg("model", wait.prompt))
                    while (history.size > 6) history.removeAt(0)
                    return wait.prompt
                }
                contents.put(JSONObject().put("role", "user").put("parts", res))
                continue
            }
            val reply = sb.toString().trim().ifEmpty { tr("ठीक है", "Okay") }
            history.add(userMsg)
            history.add(msg("model", reply))
            while (history.size > 6) history.removeAt(0)
            return reply
        }
        return tr("काम पूरा नहीं हो पाया", "I could not finish that")
    }

    // ---------- Phone actions ----------
    private fun go(i: Intent): String {
        startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "done"
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    /** Returns (display name, phone number) for a spoken name or a number. */
    private fun lookupContact(who: String): Pair<String, String>? {
        val q = who.trim()
        if (Regex("^[+0-9 \\-]{5,}$").matches(q)) {
            val d = q.filter { it.isDigit() || it == '+' }
            return Pair(d, d)
        }
        return try {
            val names = ArrayList<String>()
            val nums = ArrayList<String>()
            contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                ),
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
                arrayOf("%$q%"), null
            )?.use { c ->
                while (c.moveToNext() && names.size < 50) {
                    names.add(c.getString(0) ?: "")
                    nums.add(c.getString(1) ?: "")
                }
            }
            val idx = Logic.pickContact(q, names)
            if (idx < 0 || nums[idx].isBlank()) null else Pair(names[idx], nums[idx])
        } catch (e: SecurityException) { null }
    }

    private fun sendWhatsApp(number: String, text: String): String {
        val n = Logic.waNumber(number)
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$n?text=" + enc(text)))
        val pkg = listOf("com.whatsapp", "com.whatsapp.w4b")
            .firstOrNull { packageManager.getLaunchIntentForPackage(it) != null }
        if (pkg != null) intent.setPackage(pkg)
        go(intent)
        if (!NovaAccessibilityService.isEnabled(this)) {
            return tr("चैट खुल गई है, भेजें बटन दबा दीजिए", "The chat is open, please press send")
        }
        NovaAccessibilityService.armSend(text) { ok ->
            h.post {
                say(
                    if (ok) tr("मैसेज भेज दिया", "Message sent")
                    else tr("भेजने वाला बटन नहीं दबा पाया, आप खुद भेज दीजिए", "I could not press send, please send it yourself")
                )
            }
        }
        return tr("मैसेज भेज रहा हूँ", "Sending the message")
    }

    private fun runTool(name: String, i: JSONObject): String = when (name) {
        "open_app" -> {
            val pm = packageManager
            val q = i.getString("name").lowercase()
            val list = pm.queryIntentActivities(
                Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
            )
            val m = list.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) }
            val li = m?.let { pm.getLaunchIntentForPackage(it.activityInfo.packageName) }
            if (li != null) go(li) else "app not found"
        }
        "open_url" -> go(Intent(Intent.ACTION_VIEW, Uri.parse(i.getString("url"))))
        "call" -> {
            val c = lookupContact(i.getString("who"))
            if (c == null) "contact not found" else {
                askFirst(tr("${c.first} को कॉल करूँ?", "Shall I call ${c.first}?")) {
                    val granted = checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
                    go(Intent(if (granted) Intent.ACTION_CALL else Intent.ACTION_DIAL, Uri.fromParts("tel", c.second, null)))
                    tr("कॉल लगा रहा हूँ", "Calling now")
                }
            }
        }
        "sms" -> {
            val n = lookupContact(i.getString("to"))?.second
            if (n == null) "contact not found" else
                go(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$n")).putExtra("sms_body", i.optString("message")))
                    .let { "SMS screen opened with the message ready; the user must press send" }
        }
        "whatsapp" -> {
            val c = lookupContact(i.getString("to"))
            val text = i.optString("message")
            if (c == null) "contact not found"
            else if (text.isBlank()) "the message is empty; ask the user what to write"
            else askFirst(
                tr("${c.first} को व्हाट्सऐप पर भेजूँ: ${Logic.shorten(text)}?", "Send ${c.first} on WhatsApp: ${Logic.shorten(text)}?")
            ) { sendWhatsApp(c.second, text) }
        }
        "alarm" -> go(
            Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_HOUR, i.getInt("hour"))
                .putExtra(AlarmClock.EXTRA_MINUTES, i.getInt("minute"))
                .putExtra(AlarmClock.EXTRA_MESSAGE, i.optString("label"))
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        )
        "timer" -> go(
            Intent(AlarmClock.ACTION_SET_TIMER)
                .putExtra(AlarmClock.EXTRA_LENGTH, i.getInt("seconds"))
                .putExtra(AlarmClock.EXTRA_MESSAGE, i.optString("label"))
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        )
        "torch" -> {
            val cm = getSystemService(CameraManager::class.java)
            cm.setTorchMode(cm.cameraIdList[0], i.getBoolean("on"))
            "done"
        }
        "volume" -> {
            val am = getSystemService(AudioManager::class.java)
            when (i.getString("action")) {
                "max" -> am.setStreamVolume(AudioManager.STREAM_MUSIC, am.getStreamMaxVolume(AudioManager.STREAM_MUSIC), AudioManager.FLAG_SHOW_UI)
                "mute" -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
                "down" -> repeat(2) { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI) }
                else -> repeat(2) { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI) }
            }
            "done"
        }
        "navigate" -> go(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/dir/?api=1&destination=" + enc(i.getString("place")))))
        "play_music" -> go(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + enc(i.getString("query")))))
        "camera" -> go(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))
        "settings" -> go(
            Intent(
                when (i.getString("page")) {
                    "wifi" -> Settings.ACTION_WIFI_SETTINGS
                    "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
                    "display" -> Settings.ACTION_DISPLAY_SETTINGS
                    "sound" -> Settings.ACTION_SOUND_SETTINGS
                    "location" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
                    "battery" -> Settings.ACTION_BATTERY_SAVER_SETTINGS
                    "airplane" -> Settings.ACTION_AIRPLANE_MODE_SETTINGS
                    "apps" -> Settings.ACTION_APPLICATION_SETTINGS
                    "dnd" -> "android.settings.ZEN_MODE_PRIORITY_SETTINGS"
                    else -> Settings.ACTION_SETTINGS
                }
            )
        )
        "calendar_event" -> {
            val ms = SimpleDateFormat("yyyy-MM-dd'T'HH:mm", Locale.ENGLISH).parse(i.getString("start"))!!.time
            go(
                Intent(Intent.ACTION_INSERT).setData(CalendarContract.Events.CONTENT_URI)
                    .putExtra(CalendarContract.Events.TITLE, i.getString("title"))
                    .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, ms)
                    .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, ms + 3600000)
            ).let { "Calendar screen opened; the user must press save" }
        }
        "search_web" -> searchWeb(i.getString("query"))
        else -> "unknown tool"
    }
}
